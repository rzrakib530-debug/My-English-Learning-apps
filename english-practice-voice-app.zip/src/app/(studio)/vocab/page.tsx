import { VocabDeck } from "@/components/VocabDeck";

export const dynamic = "force-dynamic";

export default function VocabPage() {
  return <VocabDeck />;
}
